package Interface;

import java.util.EventObject;

public class StartOrientationObjectEvent extends EventObject {

	public StartOrientationObjectEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
