package Interface;

import java.util.EventObject;

public class FillValveClosedObjectEvent extends EventObject {

	public FillValveClosedObjectEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
