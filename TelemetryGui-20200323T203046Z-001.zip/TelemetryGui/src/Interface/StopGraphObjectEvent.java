package Interface;

import java.util.EventObject;

public class StopGraphObjectEvent extends EventObject {

	public StopGraphObjectEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
