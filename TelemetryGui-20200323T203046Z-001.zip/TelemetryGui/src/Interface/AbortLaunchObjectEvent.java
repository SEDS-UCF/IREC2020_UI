package Interface;

import java.util.EventObject;

public class AbortLaunchObjectEvent extends EventObject {

	public AbortLaunchObjectEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
