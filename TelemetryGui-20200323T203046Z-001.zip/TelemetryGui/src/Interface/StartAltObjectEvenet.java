package Interface;

import java.util.EventObject;

public class StartAltObjectEvenet extends EventObject {

	public StartAltObjectEvenet(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
