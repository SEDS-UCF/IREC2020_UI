package Interface;

import java.util.EventObject;

public class FillValveOpenObjectEvent extends EventObject {

	public FillValveOpenObjectEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
