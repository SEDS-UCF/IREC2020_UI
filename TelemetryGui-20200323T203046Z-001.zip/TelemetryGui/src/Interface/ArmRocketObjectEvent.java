package Interface;

import java.util.EventObject;

public class ArmRocketObjectEvent extends EventObject {

	public ArmRocketObjectEvent(Object arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
